See the 'buildbot' package for details


